import forceSSL from 'express-force-ssl';
import { Express, Request, Response, NextFunction } from 'express';

import { useSSL } from '../utils/constants';
import { fetchOperators, fetchOperator, generateInstallYaml } from '../services';
//import { } from '../services/yamlService';

const addCORSHeader = (request, response, next) => {
    const hasOrigin = request.headers.origin != null;

    response.set('Access-Control-Allow-Origin', hasOrigin ? request.headers.origin : '*');
    response.set('Access-Control-Allow-Credentials', !hasOrigin);
    response.set('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE, HEAD, OPTIONS, PATCH');

    const requestHeaders = request.headers['access-control-request-headers'];

    if (requestHeaders != null) {
        response.set('Access-Control-Allow-Headers', requestHeaders);
    }

    next();
};

const forceToSSL = (request: Request, response: Response, next: NextFunction) => {
    if (useSSL) {
        forceSSL(request, response, next);
        return;
    }

    next();
};


export default function (app: Express) {
    app.get('/api/*', forceToSSL, addCORSHeader);

    app.get('/api/operators', fetchOperators);
    app.get('/api/operator', fetchOperator);
    app.get('/install/*.yaml', generateInstallYaml);
};
