import _ from 'lodash';
import { Request, Response } from 'express';
import { operatorsIndex, operatorsData, getDefaultOperatorForPackage, getChannelMetadataList, getOperator } from '../utils';
import { OperatorDetailChannelList, NormalizedOperator } from '../types';


export function fetchOperators(request: Request, response: Response) {

    response.send({
        operators: operatorsIndex
    });
};



export function fetchOperator(request: Request, response: Response) {
    const { name, channel, packageName } = request.query;

    if (packageName) {
        const operatorPackage = operatorsData.find(opPackage => opPackage.name === packageName);

        if (operatorPackage) {
            const channelsMetadata = getChannelMetadataList(operatorPackage);
           const operator = getOperator(operatorPackage, channel, name);
            
            if (operator) {
                response.send({
                    operator: {
                        ...operator,
                        channels: channelsMetadata
                    }
                });

            } else {
                response.send({
                    operator: null
                });
            }


        } else {
            console.warn(`Server can't find operator package with name ${packageName}`);
            response.send({ operator: null });
        }
    } else {
        response.status(400).send("Request without package name is not supported");
    }    
}
